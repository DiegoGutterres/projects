window.BixoTypes = {
    fire: "fire",
    water: "water",
    grass: "grass",
    love: "love",
    ground: "ground"

}

window.Bixos = {
    "Fire001": {
        name: "Fire Billy",
        description: "Rawr!",
        type: BixoTypes.fire,
        src: "sprites/BixoFire.png",
        icon: "sprites/fireIcon.png",
        actions: [ "cegarStatus", "animadoStatus", "damage1" ],
    },
    "Fire002": {
        name: "Fire Lilly",
        description: "Rawr!",
        type: BixoTypes.fire,
        src: "sprites/BixoFire2.png",
        icon: "sprites/fireIcon.png",
        actions: [ "cegarStatus", "animadoStatus", "damage1" ],
    },

    "Water001": {
        name: "Water Mel",
        type: BixoTypes.water,
        description: "bixo desc here",
        src: "sprites/BixoWater.png",
        icon: "sprites/waterIcon.png",
        actions: [ "damage1", "cegarStatus","animadoStatus"]
    },

    "Grass001": {
        name: "Grass Walter",
        type: BixoTypes.grass,
        description: "bixo desc here",
        src: "sprites/BixoGrass.png",
        icon: "sprites/grassIcon.png",
        actions: [ "damage1"],
    },

    "Love001": {
        name: "Loved Fiona",
        type: BixoTypes.love,
        description: "bixo desc here",
        src: "sprites/BixoLove.png",
        icon: "sprites/loveIcon.png",
        actions: [ "damage1"],
    },

    "Ground001": {
        name: "Ground Rock",
        type: BixoTypes.ground,
        description: "bixo desc here",
        src: "sprites/BixoGround.png",
        icon: "sprites/groundIcon.png",
        actions: [ "damage1"],
    
    }
}