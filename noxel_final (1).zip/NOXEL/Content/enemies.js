window.Enemies = {
    "cora": {
      name: "Cora",
      src: "sprites/npc8.png",
      bixos: {
        "a": {
          bixoId: "Water001",
          maxHp: 20,
          level: 1,
        },
        "b": {
          bixoId: "Fire002",
          maxHp: 20,
          level: 1,
        },
      }
    },
    "beth": {
      name: "Beth",
      src: "sprites/npc5.png",
      bixos: {
        "a": {
          hp: 30,
          bixoId: "Love001",
          maxHp: 30,
          level: 1,
        },
      }
    },
    "nerd": {
      name: "Nerd",
      src: "sprites/npc4.png",
      bixos: {
        "a": {
          hp: 30,
          bixoId: "Grass001",
          maxHp: 30,
          level: 1,
        },
      }
    },
      "pedro": {
        name: "Pedro",
        src: "sprites/npc6.png",
        bixos: {
          "a": {
            hp: 30,
            bixoId: "Water001",
            maxHp: 30,
            level: 1,
          },
        }
      },
        "bernardo": {
          name: "Bernardo Jr",
          src: "sprites/npc7.png",
          bixos: {
            "a": {
              hp: 30,
              bixoId: "Ground001",
              maxHp: 30,
              level: 1,
            },
          }
        },
        "macaco": {
          name: "Bernardo",
          src: "sprites/npc10.png",
          bixos: {
            "a": {
              hp: 30,
              bixoId: "Ground001",
              maxHp: 30,
              level: 1,
            },
          }
        },
    }
  