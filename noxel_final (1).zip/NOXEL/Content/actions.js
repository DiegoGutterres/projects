window.Actions = {
    damage1: {
      name: "Arranhao",
      description: "Um forte arranhao do seu coala!",
      success: [
        { type: "textMessage", text: "{CASTER} usou {ACTION}!"},
        { type: "animation", animation: "spin"},
        { type: "stateChange", damage: 20}
      ]
    },
    animadoStatus: {
      name: "Se Animar",
      targetType: "friendly",
      description: "Voce e seu coala dançam!",
      success: [
        { type: "textMessage", text: "{CASTER} usou {ACTION}!"},
        { type: "stateChange", status: { type: "animado", expiresIn: 3}}
      ]
    },
    cegarStatus: {
      name: "Cegar",
      description: "Seu coala gospe na cara do inimigo!",
      success: [
        { type: "textMessage", text: "{CASTER} usou {ACTION}!"},
        { type: "animation", animation: "glob", color: "#6b3e75"},
        { type: "animation", animation: "glob", color: "#6b3e75"},
        { type: "stateChange", status: { type: "cego", expiresIn: 3}},
        { type: "textMessage", text: "{TARGET} ficou cego!"},
      ]
    },

    //itens
    item_recoverStatus: {
      name: "Suco de Cenoura",
      description: "Dizem que faz bem para visao...",
      targetType: "friendly",
      success: [
        { type: "textMessage", text: "{CASTER} tomou {ACTION}!"},
        { type: "stateChange", status: null },
        { type: "textMessage", text: "Se sentindo renovado!"},
      ]
    },

    item_recoverHp: {
      name: "Atum",
      description: "Tem um cheiro esquisito...",
      targetType: "friendly",
      success: [
        { type: "textMessage", text: "{CASTER} comeu um {ACTION}!"},
        { type: "stateChange", recover: 10 },
        { type: "textMessage", text: "{CASTER} se sente com mais vigor"},
      ]
    }








    //crackudoStatus: {
    //  name: "Pular!",
    //  success: [
     //   { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
     //   { type: "stateChange", status: { type: "animado", expiresIn: 3}}
     // ]
   // }
  }