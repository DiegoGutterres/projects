class OverworldMap {
  constructor(config) {
    this.overworld = null;
    this.gameObjects = config.gameObjects;
    this.cutsceneSpaces = config.cutsceneSpaces || {};
    this.walls = config.walls || {};

    this.lowerImage = new Image();
    this.lowerImage.src = config.lowerSrc;

    this.upperImage = new Image();
    this.upperImage.src = config.upperSrc;

    this.isCutscenePlaying = false;
  }

  drawLowerImage(ctx, cameraPerson) {
    ctx.drawImage(
      this.lowerImage, 
      utils.withGrid(10.5) - cameraPerson.x, 
      utils.withGrid(6) - cameraPerson.y
      )
  }

  drawUpperImage(ctx, cameraPerson) {
    ctx.drawImage(
      this.upperImage, 
      utils.withGrid(10.5) - cameraPerson.x, 
      utils.withGrid(6) - cameraPerson.y
    )
  } 

  isSpaceTaken(currentX, currentY, direction) {
    const {x,y} = utils.nextPosition(currentX, currentY, direction);
    return this.walls[`${x},${y}`] || false;
  }

  mountObjects() {
    Object.keys(this.gameObjects).forEach(key => {

      let object = this.gameObjects[key];
      object.id = key;

      object.mount(this);

    })
  }


  async startCutscene(events) {
    this.isCutscenePlaying = true;

    for (let i=0; i<events.length; i++) {
      const eventHandler = new OverworldEvent({
        event: events[i],
        map: this,
      })
      const result = await eventHandler.init();
      if (result === "LOST_BATTLE") {
        break;
      }
    }

    this.isCutscenePlaying = false;
    //resetar os npcs pra idle
    Object.values(this.gameObjects).forEach(object => object.doBehaviorEvent(this))
  }



  checkForActionCutscene() {
    const hero = this.gameObjects["hero"];
    const nextCoords = utils.nextPosition(hero.x, hero.y, hero.direction);
    const match = Object.values(this.gameObjects).find(object => {
      return `${object.x},${object.y}` === `${nextCoords.x},${nextCoords.y}`
    });
    if (!this.isCutscenePlaying && match && match.talking.length) {
      const relevantScenario = match.talking.find(scenario => {
        return (scenario.required || []).every(sf => {
          return playerState.storyFlags[sf]
        })
      })

      relevantScenario && this.startCutscene(relevantScenario.events)
    }
  }

  checkForFootstepCutscene() {
    const hero = this.gameObjects["hero"];
    const match = this.cutsceneSpaces[ `${hero.x},${hero.y}` ];
    if (!this.isCutscenePlaying && match) {
      this.startCutscene( match[0].events )
    }
  }

  addWall(x,y) {
    this.walls[`${x},${y}`] = true;
  }
  removeWall(x,y) {
    delete this.walls[`${x},${y}`]
  }
  moveWall(wasX, wasY, direction) {
    this.removeWall(wasX, wasY);
    const {x,y} = utils.nextPosition(wasX, wasY, direction);
    this.addWall(x,y);
  }

}

window.OverworldMaps = {
  InitRoom: {
    lowerSrc: "sprites/init.png",
    upperSrc: "sprites/init_upper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(4),
        y: utils.withGrid(4),
      }),
      npcA: new Person({
        x: utils.withGrid(6),
        y: utils.withGrid(7),
        src: "sprites/npcRandom.png",
        behaviorLoop: [
          { type: "stand",  direction: "left", time: 800 },
          { type: "stand",  direction: "up", time: 800 },
          { type: "stand",  direction: "right", time: 1200 },
          { type: "stand",  direction: "up", time: 300 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "Bem vindo a Noxel! Vamos lutar!!", faceHero: "npcA"},
              { type: "battle", enemyId: "beth"},
              { type: "addStoryFlag", flag: "DEFEATED_BETH" },
              { type: "textMessage", text: "Voce eh forte...", faceHero: "npcA"},

            ]
          }
        ]
      }),
      npcB: new Person({
        x: utils.withGrid(7),
        y: utils.withGrid(4),
        src: "sprites/npcRandom.png",
        talking: [
          {
            required: ["DEFEATED_BETH" && "DEFEATED_CORA" && "DEFEATED_MACACO" && "DEFEATED_NERD" && "DEFEATED_PEDRO" && "DEFEATED_BERNARDO"],
            events: [
              { type: "textMessage", text: "Voce derrotou todos?????", faceHero: "npcB"},
              { type: "textMessage", text: "Voce eh realmente bem forte....", faceHero: "npcB"},
              { type: "textMessage", text: "Merece seu premio...", faceHero: "npcB"},
              { type: "textMessage", text: "VEM CA AUGUSTO!", faceHero: "npcB"},  
              { who: "hero", type: "walk",  direction: "down" }, 
              { who: "hero", type: "stand",  direction: "up" },  
              { type: "textMessage", text: "AUGUSTO?"},      
              { who: "npcEspecial", type: "walk",  direction: "down", time: 1000 },
              { who: "npcEspecial", type: "walk",  direction: "down", time: 1000},
              { type: "textMessage", text:"Eai, amor", time: 2000},
              { type: "textMessage", text: "Apos todo esse caos, voce finalmente encontra seu amado", faceHero: "npcEspecial"},
              { type: "textMessage", text: "Voces vivem felizes para sempre, ficando marcado na historia como:", faceHero: "npcEspecial"},
              { type: "textMessage", text: "Pedro e sua luta incansavel por Augusto, o seu amor!", faceHero: "npcEspecial"},
              { type: "textMessage", text: "Fim!", faceHero: "npcEspecial"},
            ]
          },
          {

            events: [ 
              { type: "textMessage", text: "HAHAHAHAHA VAMOS LUTAR", faceHero: "npcB"},
              { type: "battle", enemyId: "cora"},
              { type: "addStoryFlag", flag: "DEFEATED_CORA" },
              { type: "textMessage", text: "..."}
            ]
          }
        ]
      }),
      npcEspecial: new Person({
        x: utils.withGrid(6),
        y: utils.withGrid(2),
        src: "sprites/npc9.png",
      }),

      npcC: new Person({
        x: utils.withGrid(1),
        y: utils.withGrid(3),
        src: "sprites/npcRandom.png",
        talking: [
          {
            events: [ 
              { type: "textMessage", text: "Woof woof", faceHero: "npcC"},
              { type: "battle", enemyId: "bernardo"},
              { type: "addStoryFlag", flag: "DEFEATED_BERNARDO" },
            ]
          }
        ]
      }),
      npcD: new Person({
        x: utils.withGrid(2),
        y: utils.withGrid(3),
        src: "sprites/npcRandom.png",
        talking: [
          {
            events: [ 
              { type: "textMessage", text: "Nao mecha com o Bernardo Jr!", faceHero: "npcD"},
              { type: "battle", enemyId: "macaco"},
              { type: "addStoryFlag", flag: "DEFEATED_MACACO" },
            ]
          }
        ]
      }),
      npcE: new Person({
        x: utils.withGrid(3),
        y: utils.withGrid(3),
        src: "sprites/npcRandom.png",
        talking: [
          {
            events: [ 
              { type: "textMessage", text: "Eu gosto de praia e livros", faceHero: "npcE"},
              { type: "battle", enemyId: "nerd"},
              { type: "addStoryFlag", flag: "DEFEATED_NERD" },
            ]
          }
        ]
      }),
      npcF: new Person({
        x: utils.withGrid(4),
        y: utils.withGrid(3),
        src: "sprites/npcRandom.png",
        talking: [
          {
            events: [ 
              { type: "textMessage", text: "AaaAAAaaaAA", faceHero: "npcF"},
              { type: "battle", enemyId: "pedro"},
              { type: "addStoryFlag", flag: "DEFEATED_PEDRO" },
            ]
          }
        ]
      }),
    },
    walls: {
      [utils.asGridCoord(0,2)] : true,
      [utils.asGridCoord(1,2)] : true,
      [utils.asGridCoord(2,2)] : true,
      [utils.asGridCoord(3,2)] : true,
      [utils.asGridCoord(4,2)] : true,
      [utils.asGridCoord(5,3)] : true,
      [utils.asGridCoord(7,3)] : true,
      [utils.asGridCoord(8,2)] : true,
      [utils.asGridCoord(9,2)] : true,
      [utils.asGridCoord(1,8)] : true,
      [utils.asGridCoord(2,8)] : true,
      [utils.asGridCoord(3,8)] : true,
      [utils.asGridCoord(5,8)] : true,
      [utils.asGridCoord(6,8)] : true,
      [utils.asGridCoord(7,8)] : true,
      [utils.asGridCoord(8,9)] : true,
      [utils.asGridCoord(9,9)] : true,
      [utils.asGridCoord(0,9)] : true,
      [utils.asGridCoord(1,9)] : true,
      [utils.asGridCoord(2,9)] : true,
      [utils.asGridCoord(3,9)] : true,
      [utils.asGridCoord(-1,3)] : true,
      [utils.asGridCoord(-1,4)] : true,
      [utils.asGridCoord(-1,5)] : true,
      [utils.asGridCoord(-1,6)] : true,
      [utils.asGridCoord(-1,7)] : true,
      [utils.asGridCoord(-1,8)] : true,
      [utils.asGridCoord(10,3)] : true,
      [utils.asGridCoord(10,4)] : true,
      [utils.asGridCoord(10,5)] : true,
      [utils.asGridCoord(10,6)] : true,
      [utils.asGridCoord(10,7)] : true,
      [utils.asGridCoord(10,8)] : true,
      [utils.asGridCoord(4,9)] : true,
    },
    cutsceneSpaces: {
      
      [utils.asGridCoord(6,3)]: [
        {
          events: [
            { who: "npcB", type: "walk",  direction: "left" },
            { who: "npcB", type: "stand",  direction: "up", time: 250 },
            { type: "textMessage", text:"EEEEEEEEEEEEEI!!!!!"},
            { type: "textMessage", text:"VOCE NAO PODE ENTRAR AI !!!!!!!!!!!"},
            { who: "npcB", type: "walk",  direction: "right" },
            { who: "hero", type: "walk",  direction: "down" },
            { who: "hero", type: "walk",  direction: "left" },
          ]
        }
      ],
      // [utils.asGridCoord(4,9)]: [
      //   {
      //     events: [
      //       { type: "changeMap", map:"SecondRoom"}
      //     ]
      //   }
      // ]
    }
  },
  // SecondRoom: {
  //   lowerSrc: "sprites/SecondRoom_Lower.png",
  //   upperSrc: "sprites/SecondRoom_Upper.png",
  //   gameObjects: {
  //     hero: new Person({
  //       isPlayerControlled: true,
  //       x: utils.withGrid(5),
  //       y: utils.withGrid(5),
  //     }),
  //     npcA: new Person({
  //       x: utils.withGrid(9),
  //       y: utils.withGrid(6),
  //       src: "sprites/mageAll.png",
  //       talking: [
  //         {
  //           events: [
  //             { type: "textMessage", text: "cara como vc chegou aqui? vc é incrivel!", faceHero:["npcA"] },
  //           ]
  //         }
  //       ]
  //     }),
  //     [utils.asGridCoord(6,0)]: [
  //       {
  //         events: [
  //           { type: "changeMap", map:"InitRoom"}
  //         ]
  //       }
  //     ],
  //   }
  // }   
}