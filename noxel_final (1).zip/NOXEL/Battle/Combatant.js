class Combatant {
    constructor(config, battle) {
        Object.keys(config).forEach(key => {
            this[key] = config[key];
        })
        this.hp = typeof(this.hp) === "undefined" ? this.maxHp : this.hp;
        this.battle = battle;
        
    }

    get hpPercent() {
        const percent = this.hp / this.maxHp * 100;
        return percent > 0 ? percent : 0;
    }

    get xpPercent() {
        return this.xp / this.maxXp * 100;
      }
    
      get isActive() {
        return this.battle?.activeCombatants[this.team] === this.id;
      }
    
      get givesXp() {
        return this.level * 20;
      }


    createElement() {
        this.hudElement = document.createElement("div");
        this.hudElement.classList.add("Combatant");
        this.hudElement.setAttribute("data-combatant", this.id);
        this.hudElement.setAttribute("data-team", this.team);
        this.hudElement.innerHTML = (`
            <p class="Combatant_name">${this.name}</p>
            <p class="Combatant_level"></p>
            <div class="Combatant_character_crop">
                <img class="Combatant_character" alt="${this.name}" src="${this.src}" />
            </div>
            <img class="Combatant_type" src="${this.icon}" alt="${this.type}" />
            <svg viewBox="0 0 26 3" class="Combatant_life-container">
                <rect x=0 y=0 width="0%" height=1 fill="#6e2727" />
                <rect x=0 y=1 width="0%" height=2 fill="#b33831" />
            </svg>
            <svg viewBox="0 0 26 2" class="Combatant_xp-container">
                <rect x=0 y=0 width="0%" height=1 fill="#484a77" />
                <rect x=0 y=1 width="0%" height=1 fill="#4d65b4" />
            </svg>
            <p class="Combatant_status"></p>
           

        `);

        this.bixoElement = document.createElement("img");
        this.bixoElement.classList.add("Bixo");
        this.bixoElement.setAttribute("src", this.src);
        this.bixoElement.setAttribute("alt", this.name);
        this.bixoElement.setAttribute("data-team", this.team);

        this.hpFills = this.hudElement.querySelectorAll(".Combatant_life-container > rect");
        this.xpFills = this.hudElement.querySelectorAll(".Combatant_xp-container > rect");

    }

    update(changes={}) {
        //só atualizar as coisas q vierem
        Object.keys(changes).forEach(key => {
          this[key] = changes[key]
        });
    
        //mostrando o tipo do bixin
        this.hudElement.setAttribute("data-active", this.isActive);
        this.bixoElement.setAttribute("data-active", this.isActive);
    
        //mostrando o xp e vida do bixin
        this.hpFills.forEach(rect => rect.style.width = `${this.hpPercent}%`)
        this.xpFills.forEach(rect => rect.style.width = `${this.xpPercent}%`)
    
        //mostrando o lvl do bixin
        this.hudElement.querySelector(".Combatant_level").innerText = this.level;
    
        //mostrando o status do bixin
        const statusElement = this.hudElement.querySelector(".Combatant_status");
        if (this.status) {
          statusElement.innerText = this.status.type;
          statusElement.style.display = "block";
        } else {
          statusElement.innerText = "";
          statusElement.style.display = "none";
        }
      }


      getReplacedEvents(originalEvents){
        if (this.status?.type ==="cego" && utils.randomFromArray([true, false, false])){
            return [
                { type : "textMessage", text: `${this.name} errou pq ta cego kkkkkk`},
            ]
        }
        return originalEvents
      }

      getPostEvents() {
        if(this.status?.type === "animado") {
            return [
                { type : "textMessage", text: "se sentindo animado..!"},
                { type : "stateChange", recover: 5, onCaster : true },
            ]
        }

        return [];
      }

      decrementStatus() {
        if (this.status?.expiresIn > 0) {
            this.status.expiresIn -= 1;
            if (this.status.expiresIn === 0){
                this.update({
                    status: null
                })
                return {
                    type: "textMessage",
                    text: "nao esta mais animado :("
                }
            }
        }
        return null;
    }


    init(container){
        this.createElement();
        container.appendChild(this.hudElement);
        container.appendChild(this.bixoElement);
        this.update();

    }
}

