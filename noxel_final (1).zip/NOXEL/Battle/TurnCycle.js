class TurnCycle {
  constructor({ battle, onNewEvent, onWinner }) {
    this.battle = battle;
    this.onNewEvent = onNewEvent;
    this.currentTeam = "player"; //ou enemy
    this.onWinner = onWinner;
  }

  async turn() {
    //pegar o castador
    
    const casterId = this.battle.activeCombatants[this.currentTeam];
    const caster = this.battle.combatants[casterId];
    const enemyId = this.battle.activeCombatants[caster.team === "player" ? "enemy" : "player"]
    const enemy = this.battle.combatants[enemyId];

    const submission = await this.onNewEvent({
      type: "submissionMenu",
      caster,
      enemy
      
    })

    //HHAHAHHAHAHAHAHAH
    if(submission.replacement) {
      await this.onNewEvent({
        type: "replace",
        replacement: submission.replacement
      })
      await this.onNewEvent({
        type: "textMessage",
        text: `Lute por mim, ${submission.replacement.name}!`
      })
      this.nextTurn();
      return;
    }
    
    if (submission.instanceId) {

      //Add to list to persist to player state later
      this.battle.usedInstanceIds[submission.instanceId] = true;

      //Removing item from battle state
      this.battle.items = this.battle.items.filter(i => i.instanceId !== submission.instanceId)
    }
    const resultingEvents = caster.getReplacedEvents(submission.action.success);
    
    for (let i=0; i<resultingEvents.length; i++) {
      const event = {
        ...resultingEvents[i],
        submission,
        action: submission.action,
        caster,
        target: submission.target,
      }
      await this.onNewEvent(event);
    }

    //checar por eventos posteriores
    const postEvents = caster.getPostEvents();
    for (let i=0; i<postEvents.length; i++) {
      const event = {
        ...postEvents[i],
        submission,
        action: submission.action,
        caster,
        target: submission.target,
      }
      await this.onNewEvent(event);
    }

    //O BIXO FALECEU?
    const targetDead = submission.target.hp <=0;
    if (targetDead) {
      await this.onNewEvent({
        type: "textMessage", text: `${submission.target.name} foi de comes e bebes kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk`
      })

      if (submission.target.team === "enemy"){
        const playerActiveBixoId = this.battle.activeCombatants.player;
        const xp = submission.target.givesXp;
        await this.onNewEvent({
          type:"textMessage",
          text: `Ganhou ${xp} XP!`,
          combatant: this.battle.combatants[playerActiveBixoId]
        })


        await this.onNewEvent({
          type:"giveXp",
          xp:20,
          combatant: this.battle.combatants[playerActiveBixoId]
        })
      }
      
    }

    //ALGUEM ASSASSINOU TODOS OS COALAS FOFINHOS LINDINHOS QUE A GENTE FEZ, QUE CRUELDADE?
    const winner = this.getWinningTeam();
    if (winner) {
      await this.onNewEvent({
        type: "textMessage",
        text: "Voce ganhou!"
      })
      this.onWinner(winner);
      return;
    }

    //TRAGAM OS REFORÇOS
    if (targetDead){
      const replacement = await this.onNewEvent({
        type: "replacementMenu",
        team: submission.target.team
      })
      await this.onNewEvent({
        type: "replace",
        replacement: replacement
      })
      await this.onNewEvent({
        type: "textMessage",
        text: `${replacement.name} me ajude!`
      })

    }


    //checnado se os status expiraram
    const expiredEvent = caster.decrementStatus();
    if (expiredEvent) {
      await this.onNewEvent(expiredEvent)
    }


    this.nextTurn();
  }

  nextTurn() {
    this.currentTeam = this.currentTeam === "player" ? "enemy" : "player";
    this.turn();
  }

  getWinningTeam(){
    let aliveTeams = {};
    Object.values(this.battle.combatants).forEach(c => {
      if (c.hp > 0) {
        aliveTeams[c.team] = true
      }
    })
    if (!aliveTeams["player"]) { return "enemy" }
    if (!aliveTeams["enemy"]) {return "player"}
    return null;
  }

  async init() {
    await this.onNewEvent({
     type: "textMessage",
     text: `${this.battle.enemy.name} quer te descer porrada!`
    })

    //começando a papagaiada
    this.turn();

  }

}