class Battle {
    constructor( {enemy, onComplete}) {
        this.enemy = enemy;
        this.onComplete = onComplete;

        this.combatants = {

            // "player1": new Combatant({
            //     ...Bixos.Fire001,
            //     team: "player",
            //     hp: 50,
            //     maxHp: 50,
            //     xp: 99,
            //     maxXp: 100,
            //     level: 1,
            //     status: null,
            //     isPlayerControlled: true,
            // }, this),
            // "player2": new Combatant({
            //     ...Bixos.Fire002,
            //     team: "player",
            //     hp: 50,
            //     maxHp: 50,
            //     xp: 100,
            //     maxXp: 100,
            //     level: 1,
            //     status: null,
            //     isPlayerControlled: true,
            // }, this),

            // "enemy1": new Combatant({
            //     ...Bixos.Water001,
            //     team: "enemy",
            //     hp: 1,
            //     maxHp: 50,
            //     xp: 20,
            //     maxXp: 100,
            //     level: 1,
            // }, this),

            // "enemy2": new Combatant({
            //     ...Bixos.Grass001,
            //     team: "enemy",
            //     hp: 50,
            //     maxHp: 50,
            //     xp: 30,
            //     maxXp: 100,
            //     level: 1,
            // }, this)
        }

        
        this.activeCombatants = {
            player: null, //"player1",
            enemy: null, //"enemy1",
        }

        //player team
        window.playerState.lineup.forEach(id => {
            this.addCombatant(id, "player", window.playerState.bixos[id])
          });

        //enemy team
        Object.keys(this.enemy.bixos).forEach(key => {
            this.addCombatant("e_"+key, "enemy", this.enemy.bixos[key])

        })

        this.items = []

        //colocando na bag rs
        window.playerState.items.forEach(item => {
            this.items.push({
              ...item,
              team: "player"
            })
          })
      
        this.usedInstanceIds = {};
    }
    addCombatant(id, team, config) {
        this.combatants[id] = new Combatant({
          ...Bixos[config.bixoId],
          ...config,
          team,
          isPlayerControlled: team === "player"
        }, this)
            //primeiro ato
            this.activeCombatants[team] = this.activeCombatants[team] || id;
            

    }

    createElement() {
        this.element = document.createElement("div");
        this.element.classList.add("Battle");
        this.element.innerHTML = (`
            <div class="Battle_hero">
                <img src="${'sprites/mageAll.png'}" alt="Hero"/>
            </div>

            <div class="Battle_enemy">
                <img src="${this.enemy.src}" alt="${this.enemy.name}"/>
            </div>
        `)
    }

    init(container) {
        this.createElement();
        container.appendChild(this.element);


        this.playerTeam = new Team("player", "Hero");
        this.enemyTeam = new Team("enemy", "Bully");
    
        Object.keys(this.combatants).forEach(key => {
          let combatant = this.combatants[key];
          combatant.id = key;
          combatant.init(this.element)
          
          //vasco ou mengao rapido responda
          if (combatant.team === "player") {
            this.playerTeam.combatants.push(combatant);
          } else if (combatant.team === "enemy") {
            this.enemyTeam.combatants.push(combatant);
          }
        })
    
        this.playerTeam.init(this.element);
        this.enemyTeam.init(this.element);
    
        this.turnCycle = new TurnCycle({
            battle: this,
            onNewEvent: event => {
              return new Promise(resolve => {
                const battleEvent = new BattleEvent(event, this)
                battleEvent.init(resolve);
              })
            },
            onWinner: winner => {

                if (winner === "player"){
                    const playerState = window.playerState;
                    Object.keys(playerState.bixos).forEach(id => {
                        const playerStateBixo = playerState.bixos[id];
                        const combatant = this.combatants[id]
                        if (combatant) {
                            playerStateBixo.hp = combatant.hp;
                            playerStateBixo.xp = combatant.xp;
                            playerStateBixo.maxHp = combatant.maxXp;
                            playerStateBixo.level - combatant.level;
                        }
                    })

                    playerState.items = playerState.items.filter(item => {
                        return !this.usedInstanceIds[item.instanceId]
                    })


                    //MOSTRAR Q TA UPDANTDE
                    utils.emitEvent("PlayerStateUpdated")
                }


                this.element.remove();
                this.onComplete(winner === "player");
            }
          })
          this.turnCycle.init();
    
    
      }
    
    }