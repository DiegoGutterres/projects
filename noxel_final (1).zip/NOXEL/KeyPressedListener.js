class KeyPressListener {
    constructor(keyCode, callback) {
        let keySafe = true;
        this.keydownFunciontion = function(event) {
            if (event.code === keyCode){
                if (keySafe) {
                    keySafe = false;
                    callback();
                }
            }
        };
        this.keyupFunction = function(event) {
            if (event.code === keyCode) {
                keySafe = true;
            }
        };


        document.addEventListener("keydown", this.keydownFunciontion);
        document.addEventListener("keyup", this.keyupFunction);
    }
    
    unbind() {
        document.removeEventListener("keydown", this.keydownFunciontion);
        document.removeEventListener("keyup", this.keyupFunction); 
    }


}

